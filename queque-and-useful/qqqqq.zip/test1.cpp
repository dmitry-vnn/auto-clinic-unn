﻿#ifdef _DEBUG

#include <gtest/gtest.h>

TEST(test1, test)
{
	EXPECT_EQ(1, 1);
}

#endif
