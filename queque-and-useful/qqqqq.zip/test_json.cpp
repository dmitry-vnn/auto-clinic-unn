#ifdef _DEBUG

#include <gtest/gtest.h>
#include "json.hpp"

TEST(json, test) {
	
	SUCCEED();

}

#endif
