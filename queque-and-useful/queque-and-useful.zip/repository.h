﻿#pragma once
#include "queue.h"

class PatientRepository
{

private:
	Queue<const Patient*, Order::ORDERED> _queue;

public:


	PatientRepository() : _queue(100) {}

	PatientRepository(const PatientRepository& other) = delete;
	PatientRepository& operator=(const PatientRepository& other) = delete;

public:
	std::unique_ptr<const Patient> Pop();
	void Push(const Patient* patient);

	size_t Size() const { return _queue.Size(); }
	void Clear() { _queue.Clear();  }

	bool IsFull() const { return _queue.IsFull();  }
	bool IsEmpty() const { return _queue.IsEmpty();  }

};
