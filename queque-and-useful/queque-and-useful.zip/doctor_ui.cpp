﻿#include "doctor_ui.h"

#define print std::cout

#define println(x) std::cout << (x) << std::endl 

#define ln std::endl
#define scan std::cin

namespace doctor_internals
{
	size_t ToSizeTOrElse(const std::string& str, size_t orElse)
	{
		try {
			int i = std::stoi(str);
			return i < 0 ? orElse : i;
		} catch (const std::exception&)
		{
			return orElse;
		}
	}






	void ServePatient(std::unique_ptr<Patient> patient)
	{
		print << "Вы обслуживаете пациента: " <<
			patient->GetLastName() << " " << patient->GetFirstName() << " " << patient->GetPatronymic() << ln;


		print << ln << "Сведения: " << ln;

		print << "- Состояние: ";

		switch (patient->GetState().GetType()) {

			case State::NORMAL:
				print << "В норме";
				break;

			case State::MEDIUM:
				print << "Среднее";
				break;

			case State::CRITICAL:
				print << "Критическое";
				break;

		}

		print << ln << " - Класс: ";

		if (patient->GetType() == PATIENT)
		{
			print << "Обычный" << ln;
		} else
		{
			print << "Мажорный" << ln;

			const auto& majorPatient = dynamic_cast<MajorPatient*>(patient.get());

			print << "- Куш: " << majorPatient->GetMoney() << ln;

		}
	}
}


void DoctorUI::Start()
{

	print << "Здравствуйте, %docname%" << ln;

	while (true)
	{
		std::string action;
		print << "Что будет делать? ЗАПРОСИТЬ ПАЦИЕНТА - 1, ВЫХОД - 2: ";
		scan >> action;

		size_t actionType = doctor_internals::ToSizeTOrElse(action, 0);

		if (actionType < 1 || actionType > 2)
		{
			print << ln << "Неизвестное действие, попробуйте снова!" << ln;
			continue;
		}

		if (actionType == 2)
		{
			//TODO
			print << "Goodbye!" << ln;
			break;
		}

		if (actionType == 1)
		{
			try
			{
				const auto& patientAsString = _clientService->GetPatientAsString();

				auto patient = _converter.Build(patientAsString);

				doctor_internals::ServePatient(std::move(patient));

			} catch (const BadResponse& response)
			{
				print << "Не удалось получить пациента, повторите попытку" << ln;
				print << "Ответ сервера: ";

				auto serverResponseType = response.GetResponseType();

				switch (serverResponseType) {

					case ServerResponseType::NO_RESPONSE_ERR:
						print << "Ответ не был получен";
						break;
					case ServerResponseType::QUEUE_IS_EMPTY_ERR: 
						print << "Очередь пуста";
						break;
					default:
						print << "UNKNOWN";
						break;
			
				}

				print << ln;


			} catch (const PatientConvertError& err)
			{
				print << "Не удалось распознать данные пациента, повторите попытку" << ln;
				print << "Причина: " << err.what() << ln;
			} 
			
		}
	}

}
