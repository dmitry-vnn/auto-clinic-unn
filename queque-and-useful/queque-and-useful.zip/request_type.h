﻿#pragma once

//CLIENT TO SERVER REQUEST TYPE
enum class ClientRequestType
{

	LOGIN, //And next login and password data
	GET_PATIENT,
	LOGOUT

};


//SERVER TO CLIENT RESPONSE TYPE
enum class ServerResponseType {

	NO_RESPONSE_ERR,

	LOGIN_OK,
	INCORRECT_LOGIN_ERR,

	GET_PATIENT_OK, //And next patient from JSON
	QUEUE_IS_EMPTY_ERR,

	LOGOUT_OK

};



