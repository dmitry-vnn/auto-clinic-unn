﻿#include "reception_ui.h"

#include "client_service.h"


#define print std::cout

//#define define println(x) std::cout << (x) << std::endl 

#define ln std::endl
#define scan std::cin

namespace reception_internals
{
	size_t ToSizeTOrElse(const std::string& str, size_t orElse)
	{
		try {
			int i = std::stoi(str);
			return i < 0 ? orElse : i;
		} catch (const std::exception&)
		{
			return orElse;
		}
	}

	bool NameIsValid(const std::string& name)
	{
		if (name.length() < 2)
		{
			return false;
		}


		for (auto c : name)
		{
			c = tolower(c);

			if (!(c >= 'a' && c <= 'z'))
			{
				return false;
			}

		}

		return true;

	}


	Patient* TryCreatePatientOnHeap()
	{
		while (true)
		{
			print << " * Для отмены создания пациента, напишите -1" << ln;

			std::string firstName;

			while (true)
			{
				print << " - Имя? >> ";

				scan >> firstName;

				if (firstName == "-1")
				{
					return nullptr;
				}

				if (!NameIsValid(firstName))
				{
					print << " - Усп, проверьте правильность ввода, попробуйте ещё раз" << ln;
					continue;
				}

				break;

			}

			std::string lastName;

			while (true)
			{
				print << " - Фамилия? >> ";

				scan >> firstName;

				if (firstName == "-1")
				{
					return nullptr;
				}

				if (!NameIsValid(firstName))
				{
					print << " - Усп, проверьте правильность ввода, попробуйте ещё раз" << ln;
					continue;
				}

				break;

			}

			std::string patronymic;

			while (true)
			{
				print << " - Отчество? (если нет -> ENTER) >> ";

				scan >> patronymic;

				if (patronymic == "-1")
				{
					return nullptr;
				}

				if (patronymic.empty())
				{
					break;
				}

				if (!NameIsValid(patronymic))
				{
					print << " - Усп, проверьте правильность ввода, попробуйте ещё раз" << ln;
					continue;
				}

				break;

			}


			State state = State::NORMAL;

			while (true)
			{
				std::string stateAsString;

				print << " - Состояние? (1 (по умолчанию) - В ПОРЯДКЕ, 2 - НУ ТАКОЕ, 3 - ХАРДКОР) >> ";

				scan >> stateAsString;

				if (stateAsString == "-1")
				{
					return nullptr;
				}

				if (stateAsString.empty() || stateAsString == "1")
				{
					break;
				}

				if (stateAsString == "2")
				{
					state = State::MEDIUM;
					break;
				}

				if (stateAsString == "3")
				{
					state = State::CRITICAL;
					break;
				}

				print << " - Усп, проверьте правильность ввода, попробуйте ещё раз" << ln;

			}

			bool isMajor = false;

			while (true)
			{
				std::string isMajorAsStr;

				print << " - Мажор? (n (по умолчанию) - НЕТ, y - ДА) >> ";

				scan >> isMajorAsStr;

				if (isMajorAsStr == "-1")
				{
					return nullptr;
				}

				if (isMajorAsStr.empty() || isMajorAsStr == "n")
				{
					break;
				}

				if (isMajorAsStr == "y")
				{
					isMajor = true;
					break;
				}

				print << " - Усп, проверьте правильность ввода, попробуйте ещё раз" << ln;
			}

			size_t money = 0;

			if (isMajor)
			{
				while (true)
				{
					std::string moneyAsStr;

					print << " - Лавешки? >> ";

					scan >> moneyAsStr;

					if (moneyAsStr == "-1")
					{
						return nullptr;
					}

					money = ToSizeTOrElse(moneyAsStr, 0);

					if (money == 0)
					{
						print << " - Усп, проверьте правильность ввода, попробуйте ещё раз" << ln;
						continue;
					}

					break;
				}
			}

			return isMajor ?
				new MajorPatient(money, firstName, lastName, patronymic, state) :
				new Patient(firstName, lastName, patronymic, state);
		}
	}
}


void PatientReceptionUI::Start()
{

	// print << "---- Клиника %CLINIC_NAME% начинает свою работу ----" << ln;

	print << "---- Стартуем ресепшн... ----" << ln;

	Sleep(500);
	print << " * Поднимаем сервера..." << ln;

	Sleep(500);
	print << "---- УСПЕХ. Можете работать ----" << ln;

	print << ln;


	while (true)
	{
		print << " - Шо будем делать ?: СЫБАТЬСЯ: 1, ДОБАВИТЬ: 2, БАЗА: 3, ДРОПНУТЬ: 4, САЙЗ : 5  >> ";

		std::string actionAsStr;

		std::getline(scan, actionAsStr);

		size_t action = reception_internals::ToSizeTOrElse(actionAsStr, 0);

		if (action == 0)
		{
			print << " - Упс, ошибочка, попробуйте снова" << ln;
			continue;
		}

		if (action == 1)
		{
			print << " - Досвидули!" << ln;
			return;
		}

		if (action == 2)
		{

			Patient* patient = reception_internals::TryCreatePatientOnHeap();

			if (patient == nullptr)
			{
				continue;
			}

			_repository->Push(patient);


			print << " - Пациент успешно записан!" << ln;
			continue;
		}

		if (action == 3)
		{
			print << " - //TODO" << ln;
			continue;
		}

		if (action == 4)
		{
			_repository->Clear();

			print << " - Успешно дропнуто" << ln;
			continue;
		}

		if (action == 5)
		{
			print << " - Пациентов записано: " << _repository->Size() << ln;
		}

	}



}
