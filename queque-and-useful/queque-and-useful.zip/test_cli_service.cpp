﻿#ifdef _DEBUG

#include <gtest/gtest.h>

#include "client_service.h"

#endif
