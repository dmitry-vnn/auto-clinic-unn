﻿#pragma once

#include <WinSock2.h>
#include <WS2tcpip.h>
#include <iostream>
#include <string>

#include "queue.h"
#include "repository.h"

#pragma comment(lib, "ws2_32.lib")

class ConnectionsService
{
private:

	PatientRepository* _repository;
	PatientConverter _converter;

	std::string _port;

	SOCKET _serverSocket;


public:
	ConnectionsService(size_t port, PatientRepository* repository) : _repository(repository), _converter(), _port(std::to_string(port)), _serverSocket(INVALID_SOCKET)
	{
		assert(repository != nullptr, "repository must be not null");
	}

	bool TryStart();
	void StartListenConnections();

	ConnectionsService(const ConnectionsService& other) = delete;
	ConnectionsService& operator=(const ConnectionsService& other) = delete;

private:

};
