﻿#include "repository.h"

std::unique_ptr<const Patient> PatientRepository::Pop()
{
	if (_queue.IsEmpty())
	{
		throw std::out_of_range("Repository is empty");
	}

	return std::unique_ptr<const Patient>(_queue.Pop());
}

void PatientRepository::Push(const Patient* patient)
{
	if (_queue.IsFull())
	{
		throw std::out_of_range("Repository is full");
	}

	_queue.Push(patient);
}
